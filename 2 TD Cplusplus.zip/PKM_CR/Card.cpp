//
// Created by lucad on 08/01/2024.
//

#include "Card.h"

Card::Card(string _cardName):
cardName(_cardName)
{
}

string Card::getName() const
{
    return this->cardName;
}
